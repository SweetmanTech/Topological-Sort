# Topological Sort
Java Adjacency List Data Structure implementation of graph with Topological Sort DFS for CSE 2321: Foundations 1
# Setup
* Download and extract TopologicalSort.zip
* `cd TopologicalSort`
# Compile
`javac TopologicalSort.java`
# Run
`java TopologicalSort graphX.txt`
